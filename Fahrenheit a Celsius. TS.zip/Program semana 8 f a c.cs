﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Fahrenheit a Celsius");
{
    int grado;
    int res;
    Console.WriteLine("Ingrese el numero: ");
    grado = Convert.ToInt32(Console.ReadLine());
    res = (grado - 32) * 5 / 9;
    Console.WriteLine("Fahrenheit:  " + grado + " = Celsius: " + res);
    Console.ReadLine();
}
