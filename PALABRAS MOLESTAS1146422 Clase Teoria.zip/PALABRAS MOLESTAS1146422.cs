﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Lista de palabras");

string palabra = "";
int cont = 0;
Console.WriteLine("ingrese una palabra: ");
palabra = Console.ReadLine();

if (palabra != palabra.ToUpper())
{
    for (int i = 0; i < palabra.Length; i++)
    {
        if (palabra[i] == "!")
            {
        cont++;
    }
    else
    {
        cont = 0;
    }
    }
}
else if (palabra == palabra.ToUpper())
{
    Console.WriteLine("Es ua palabra molesta");
}
else if (cont>=2)
{
    Console.WriteLine("Es una palabra molesta");
}

else
{
    Console.WriteLine("No es una palabra molesta");
}

Console.ReadKey();